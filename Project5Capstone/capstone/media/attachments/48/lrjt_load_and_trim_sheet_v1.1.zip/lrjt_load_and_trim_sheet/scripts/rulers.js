/* ──────────────── scripts/rulers.js ──────────────── */

/**
 * Draws the frames and content for all horizontal rulers.
 * @param {d3.Selection} svg The D3 selection of the SVG group element for the rulers.
 * @param {object} cfg The configuration object from CONFIG.rulers.
 */
function drawRulers(svg, cfg) {
  const rh = cfg.height / cfg.rulerCount;
  const unit = cfg.width / cfg.ruler1Range;
  const xRef = unit * cfg.refTick;

  // Draw the outer frame for each ruler
  for (let i = 0; i < cfg.rulerCount; i++) {
    svg
      .append("rect")
      .attr("x", 0)
      .attr("y", i * rh)
      .attr("width", cfg.width)
      .attr("height", rh)
      .attr("fill", "none")
      .attr("stroke", "black");
  }

  // Draw the unique pattern for the first ruler
  drawRuler1(svg, rh, unit, cfg);

  // Draw the generic pattern for all other rulers
  for (let i = 2; i <= cfg.rulerCount; i++) {
    drawGenericRuler(svg, i, rh, unit, xRef, cfg);
  }
}

/**
 * Draws the specific content for Ruler 1 (the main INDEX ruler).
 * @param {d3.Selection} svg The D3 selection of the SVG group element.
 * @param {number} rh The height of a single ruler in pixels.
 * @param {number} unit The number of pixels per one INDEX unit.
 * @param {object} cfg The configuration object from CONFIG.rulers.
 */
function drawRuler1(svg, rh, unit, cfg) {
  const g = svg.append("g");
  const majL = rh * cfg.majorRatio;
  const minL = rh * cfg.minorRatio;

  for (let v = 0; v <= cfg.ruler1Range; v++) {
    const x = v * unit;
    if (x < 0 || x > cfg.width) continue; // Clamp to frame

    const major = v % 5 === 0;
    g.append("line")
      .attr("x1", x)
      .attr("x2", x)
      .attr("y1", rh)
      .attr("y2", rh - (major ? majL : minL))
      .attr("stroke", "black")
      .attr("stroke-width", major ? cfg.majorWidth : cfg.minorWidth);

    if (major && v % 10 === 0 && v !== 0 && v !== cfg.ruler1Range) {
      g.append("text")
        .attr("x", x)
        .attr("y", rh - majL - 1)
        .attr("text-anchor", "middle")
        .attr("font-size", cfg.labelFont[1].size - 1)
        .text(v);
    }
  }
  g.append("text").attr("x", 4).attr("y", 12).attr("font-size", cfg.labelFont[1].size).text(cfg.identifierLabels[1]);
}

/**
 * Draws the content for a generic ruler (rulers 2-10).
 * This includes ticks, data rectangles (with triangles), and identifier rectangles.
 * @param {d3.Selection} svg The D3 selection of the SVG group element.
 * @param {number} idx The 1-based index of the ruler to draw.
 * @param {number} rh The height of a single ruler in pixels.
 * @param {number} unit The number of pixels per one INDEX unit.
 * @param {number} xRef The pixel coordinate of the reference tick.
 * @param {object} cfg The configuration object from CONFIG.rulers.
 */
function drawGenericRuler(svg, idx, rh, unit, xRef, cfg) {
  const ratio = cfg.ratios[idx - 1];
  const majDX = unit * 5 * ratio;
  const yTop = (idx - 1) * rh;
  const g = svg.append("g").attr("transform", `translate(0,${yTop})`);
  const anchorX = cfg.anchor(idx) === "ref" ? xRef : 0;

  let majors = [];
  for (let k = 0, x = anchorX; x >= -majDX; k--, x = anchorX + k * majDX) majors.unshift({ x, k });
  for (let k = 1, x = anchorX + majDX; x <= cfg.width + majDX; k++, x = anchorX + k * majDX) majors.push({ x, k });

  const rectH = rh * cfg.rectHRatio;
  const rectY = rh - rectH;
  const side = cfg.rectSide[idx];
  const tri = cfg.triSide[idx];
  const t = cfg.triW;
  const rectWidthInCells = cfg.rectWidthInCells[idx];

  // --- Data Rectangle (with triangles) ---
  let baseRectW, boundingStart, boundingEnd, cellX;
  if (side === "right") {
    baseRectW = cfg.rightRectWidth;
    boundingEnd = cfg.width;
    boundingStart = cfg.width - baseRectW;
    cellX = boundingStart;
  } else {
    cellX = (cfg.width - 2 * majDX) / 2;
    baseRectW = rectWidthInCells * majDX;
    boundingStart = null;
    boundingEnd = null;
  }

  boundingStart = Math.max(0, Math.min(cfg.width, boundingStart));
  boundingEnd = Math.max(0, Math.min(cfg.width, boundingEnd));

  majors.forEach(({ x: mx, k }) => {
    const full = idx !== 10 || k % 2 === 0;
    const len = full ? rh : rh * 0.6;
    const y1 = full ? 0 : (rh - len) / 2;
    let offset = 0;
    if (idx !== 10) {
      if (cfg.triSide[idx] === "left") offset = majDX;
      if (cfg.triSide[idx] === "right") offset = -majDX;
    }

    const x1 = mx + offset;
    const x2 = mx;
    let skip = false;
    if (boundingStart !== null && boundingEnd !== null) {
      const segMin = Math.min(x1, x2);
      const segMax = Math.max(x1, x2);
      if (segMax > boundingStart && segMin < boundingEnd) skip = true;
    }
    if (skip || mx > cfg.width) return;

    g.append("line")
      .attr("x1", x1)
      .attr("x2", x2)
      .attr("y1", y1)
      .attr("y2", y1 + len)
      .attr("stroke", "black")
      .attr("stroke-width", cfg.majorWidth);
  });

  let rectX = cellX,
    rectW = baseRectW;
  if (tri === "left") {
    rectX += t;
    rectW -= t;
  } else if (tri === "right") {
    rectW -= t;
  } else if (tri === "both") {
    rectX += t;
    rectW -= 2 * t;
  }

  g.append("rect")
    .attr("x", rectX + 0.5)
    .attr("y", rectY + 0.5)
    .attr("width", rectW - 1)
    .attr("height", rectH - 1)
    .attr("fill", "white")
    .attr("stroke", "black");

  // Triangles
  if (boundingStart !== null && boundingEnd !== null) {
    if (tri === "left" || tri === "both") {
      g.append("polygon")
        .attr(
          "points",
          `${boundingStart + t},${rectY} ${boundingStart},${rectY + rectH / 2} ${boundingStart + t},${rectY + rectH}`
        )
        .attr("fill", "black");
    }
    if (tri === "right" || tri === "both") {
      g.append("polygon")
        .attr(
          "points",
          `${boundingEnd - t},${rectY} ${boundingEnd},${rectY + rectH / 2} ${boundingEnd - t},${rectY + rectH}`
        )
        .attr("fill", "black");
    }
  }

  // --- Identifier Rectangle (left side, no triangles) ---
  const labelRectWidth = 15 * unit;
  g.append("rect")
    .attr("x", 0.5)
    .attr("y", 0.5)
    .attr("width", labelRectWidth - 1)
    .attr("height", rh - 1)
    .attr("fill", "white")
    .attr("stroke", "black");

  // Identifier Label (uses `identifierLabels` from CONFIG)
  g.append("text")
    .attr("x", labelRectWidth / 2)
    .attr("y", rh / 2)
    .attr("text-anchor", "middle")
    .attr("dominant-baseline", "middle")
    .attr("font-size", (cfg.labelFont[idx] || {}).size || 11)
    .text(cfg.identifierLabels[idx]);

  // Data Label for the rectangle with triangles (uses `dataLabels` from CONFIG)
  const dataLabelText = cfg.dataLabels[idx];
  if (dataLabelText) {
    const pos = cfg.labelPos[idx] || "center";
    const fnt = cfg.labelFont[idx] || { size: 11 };
    const yLbl = rectY + rectH / 2;
    let xLbl, anchor;
    if (pos === "left") {
      xLbl = rectX + 4;
      anchor = "start";
    } else if (pos === "right") {
      xLbl = rectX + rectW - 4;
      anchor = "end";
    } else {
      xLbl = rectX + rectW / 2;
      anchor = "middle";
    }

    g.append("text")
      .attr("x", xLbl)
      .attr("y", yLbl)
      .attr("text-anchor", anchor)
      .attr("dominant-baseline", "middle")
      .attr("font-size", fnt.size)
      .text(dataLabelText);
  }
}

/**
 * Draws a continuous path through the rulers for a specific mass type (ZFW or TOW).
 * @param {d3.Selection} svg The D3 selection of the SVG group element for the rulers.
 * @param {object} cfg The configuration object from CONFIG.rulers.
 * @param {string} type The mass type, either "ZFW" or "TOW".
 */
function drawInputLines(svg, cfg, type) {
  const lineColor = CONFIG.chart.massLineColors[type] || "black";
  const rh = cfg.height / cfg.rulerCount;
  const baseUnit = cfg.width / cfg.ruler1Range;
  const path = d3.path();

  // ZFW line ignores the fuel index, TOW line includes it.
  const lineMapping = type === "ZFW" ? cfg.lineMapping.filter((m) => m.id !== "fuelIndex") : cfg.lineMapping;

  const x0 = baseUnit * Number(document.getElementById("dryOpIndex").value);
  let x = x0,
    y = rh / 2;
  path.moveTo(x, y);

  // Draw path segments through each relevant ruler
  lineMapping.slice(1).forEach(({ id, ruler, direction, unitPerValue }) => {
    y = (ruler - 1) * rh + rh / 2;
    path.lineTo(x, y);
    if (direction === "left" || direction === "right") {
      const ratio = cfg.ratios[ruler - 1] || 1;
      const pxPerValue = (baseUnit * ratio) / unitPerValue;
      const v = Number(document.getElementById(id).value);
      x += (direction === "right" ? 1 : -1) * v * pxPerValue;
      path.lineTo(x, y);
    }
  });

  // Handle the final segment of the line
  if (type === "ZFW") {
    // For ZFW, drop vertically down from its last calculated position through the final ruler space
    const lastRulerInMapping = lineMapping[lineMapping.length - 1].ruler;
    const nextRulerY = lastRulerInMapping * rh + rh / 2;
    path.lineTo(x, nextRulerY); // Move to the center of the next ruler (fuel)
    path.lineTo(x, cfg.height); // Drop straight to the bottom
  } else {
    // For TOW, continue to the bottom border from its final position
    path.lineTo(x, cfg.height);
  }

  // Append the final path and start marker to the SVG
  svg
    .append("path")
    .attr("class", `input-line input-line-${type}`)
    .attr("d", path)
    .attr("stroke", lineColor)
    .attr("stroke-width", 2)
    .attr("fill", "none");
  svg
    .append("polygon")
    .attr("class", `input-line-marker input-line-marker-${type}`)
    .attr("points", `${x0 - 6},${rh / 2 - 6} ${x0 + 6},${rh / 2 - 6} ${x0},${rh / 2}`)
    .attr("fill", lineColor);
}
