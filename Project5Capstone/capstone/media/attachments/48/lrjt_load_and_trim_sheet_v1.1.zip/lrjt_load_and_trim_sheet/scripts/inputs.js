/**
 * @file Manages the dynamic rendering of the input panels, including mass groups and status indicators.
 */

/**
 * Renders the new left-side input panel with all its sections, applying consistent styling.
 * @param {object} cfg The configuration object from CONFIG.leftPanel.
 */
function renderLeftPanel(cfg) {
  const panel = document.getElementById("leftInputPanel");
  panel.innerHTML = ""; // Clear existing content
  cfg.sections.forEach((section) => {
    const sectionDiv = document.createElement("div");
    sectionDiv.className = "panel-section";

    const title = document.createElement("div");
    title.className = "section-title";
    title.textContent = section.title;
    sectionDiv.appendChild(title);

    // Based on section type, call the appropriate rendering function
    if (section.type === "weightCalculations") {
      renderWeightCalculations(sectionDiv, section.fields);
    } else if (section.type === "dowConditions") {
      renderDowConditions(sectionDiv, section);
    } else if (section.type === "zones") {
      renderZones(sectionDiv, section);
    } else if (section.type === "indexCorrection") {
      renderIndexCorrection(sectionDiv, section);
    }

    panel.appendChild(sectionDiv);
  });
}

/**
 * Renders the "WEIGHT CALCULATIONS" section using a flexible div-based layout.
 * @param {HTMLElement} container The parent element to render into.
 * @param {object[]} fields The configuration for the fields in this section.
 */
function renderWeightCalculations(container, fields) {
  fields.forEach((field) => {
    const row = document.createElement("div");
    row.className = "form-row";
    row.innerHTML = `<div class="label">${field.label}</div>`;

    const valueContainer = document.createElement("div");
    valueContainer.className = "value";

    if (field.type === "passengers") {
      const wrapper = document.createElement("div");
      wrapper.className = "passenger-inputs";
      const input1 = document.createElement("input");
      input1.type = "number";
      input1.id = field.id + "1";
      input1.value = field.default1 || "";
      input1.maxLength = 3;
      const input2 = document.createElement("input");
      input2.type = "number";
      input2.id = field.id + "2";
      input2.value = field.default2 || "";
      input2.maxLength = 2;
      wrapper.append(input1, input2);
      valueContainer.appendChild(wrapper);
    } else {
      const input = document.createElement("input");
      input.type = field.type === "output" ? "text" : "number";
      input.id = field.id;
      input.readOnly = field.type === "output";
      if (field.defaultValue) input.value = field.defaultValue;
      if (input.readOnly) input.style.backgroundColor = CONFIG.rightPanel.outputFieldBackground;
      valueContainer.appendChild(input);
    }
    row.appendChild(valueContainer);
    container.appendChild(row);
  });
}

/**
 * Renders the "DRY OPERATING WEIGHT CONDITIONS" section with labels above inputs.
 * @param {HTMLElement} container The parent element to render into.
 * @param {object} sectionCfg The configuration for this specific section.
 */
function renderDowConditions(container, sectionCfg) {
  const mainRow = document.createElement("div");
  mainRow.className = "dow-conditions-row";

  // Weight Group (2/3 width)
  const weightGroup = document.createElement("div");
  weightGroup.className = "dow-group weight";
  const weightLabel = document.createElement("label");
  weightLabel.htmlFor = sectionCfg.fields[0].id;
  weightLabel.textContent = sectionCfg.fields[0].label;
  const weightInput = document.createElement("input");
  weightInput.type = "number";
  weightInput.id = sectionCfg.fields[0].id;
  weightInput.value = sectionCfg.fields[0].defaultValue;
  weightGroup.append(weightLabel, weightInput);

  // CG Group (1/3 width)
  const cgGroup = document.createElement("div");
  cgGroup.className = "dow-group cg";
  const cgLabel = document.createElement("label");
  cgLabel.htmlFor = sectionCfg.fields[1].id;
  cgLabel.textContent = sectionCfg.fields[1].label;
  const cgInput = document.createElement("input");
  cgInput.type = "number";
  cgInput.id = sectionCfg.fields[1].id;
  cgInput.value = sectionCfg.fields[1].defaultValue;
  cgGroup.append(cgLabel, cgInput);

  mainRow.append(weightGroup, cgGroup);
  container.appendChild(mainRow);

  const formula = document.createElement("div");
  formula.className = "section-subtitle";
  formula.style.textAlign = "center";
  formula.textContent = sectionCfg.formula;
  container.appendChild(formula);

  const outputRow = document.createElement("div");
  outputRow.className = "form-row";
  outputRow.innerHTML = `<div class="label">${sectionCfg.output.label}</div>`;
  const outputValue = document.createElement("div");
  outputValue.className = "value";
  const outputInput = document.createElement("input");
  outputInput.type = "text";
  outputInput.id = sectionCfg.output.id;
  outputInput.readOnly = true;
  outputInput.style.backgroundColor = CONFIG.rightPanel.outputFieldBackground;
  outputValue.appendChild(outputInput);
  outputRow.appendChild(outputValue);
  container.appendChild(outputRow);
}

/**
 * Renders the "ZONES" section with a multi-column table layout.
 * @param {HTMLElement} container The parent element to render into.
 * @param {object} sectionCfg The configuration for this specific section.
 */
function renderZones(container, sectionCfg) {
  const table = document.createElement("table");
  table.className = "multi-column-table";
  const thead = document.createElement("thead");
  let headerHtml = "<tr>";
  sectionCfg.headers.forEach((h) => (headerHtml += `<th>${h}</th>`));
  headerHtml += "</tr>";
  thead.innerHTML = headerHtml;
  table.appendChild(thead);

  const tbody = document.createElement("tbody");
  sectionCfg.rows.forEach((rowData) => {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${rowData.label}</td>`;
    rowData.fields.forEach((field) => {
      const cell = document.createElement("td");
      const input = document.createElement("input");
      input.type = "number";
      input.id = field.id;
      input.value = field.defaultValue || "0";
      cell.appendChild(input);
      row.appendChild(cell);
    });
    tbody.appendChild(row);
  });
  table.appendChild(tbody);
  container.appendChild(table);
}

/**
 * Renders the "BASIC INDEX CORRECTION" section using a structured HTML table.
 * This function creates a table with two main header rows to group the columns logically.
 * The layout uses `rowspan` and `colspan` for proper header grouping and relies on CSS
 * with `table-layout: fixed` to enforce a 50/50 width distribution between the main
 * description column and the three "ZONES" value columns.
 * @param {HTMLElement} container The parent element to render the section into.
 * @param {object} sectionCfg The configuration object for this section.
 */
function renderIndexCorrection(container, sectionCfg) {
  // Helper to format numbers with an explicit '+' for positive values.
  const formatSign = (num) => (num > 0 ? `+${num.toFixed(2)}` : num.toFixed(2));

  const table = document.createElement("table");
  table.className = "index-correction-table";

  const thead = table.createTHead();
  const headerRow1 = thead.insertRow();

  // The "DRY OPER. WEIGHT DEVIATION" header spans two rows to align with both the main "ZONES" header and the E, F, G sub-headers.
  // This is a key layout decision to create a clean, grouped header structure.
  const th1 = document.createElement("th");
  th1.textContent = sectionCfg.col1Title;
  th1.rowSpan = 2;
  th1.className = "styled-header main-header";
  headerRow1.appendChild(th1);

  // The "ZONES" header spans the three sub-columns (E, F, G), acting as a group title.
  const th2 = document.createElement("th");
  th2.textContent = sectionCfg.col2Title;
  th2.colSpan = 3;
  th2.className = "styled-header zones-header-group";
  headerRow1.appendChild(th2);

  // The second header row contains only the individual zone labels (E, F, G) under the main "ZONES" group.
  const headerRow2 = thead.insertRow();
  sectionCfg.subHeaders.forEach((h) => {
    const th = document.createElement("th");
    th.textContent = h;
    headerRow2.appendChild(th);
  });

  // --- Table Body (tbody) ---
  const tbody = table.createTBody();
  sectionCfg.refValues.forEach((ref) => {
    const row = tbody.insertRow();
    row.insertCell().textContent = ref.label;
    row.insertCell().textContent = formatSign(ref.e);
    row.insertCell().textContent = formatSign(ref.f);
    row.insertCell().textContent = formatSign(ref.g);
  });

  container.appendChild(table);

  // --- Output Row (kept outside the table for consistent styling with other sections) ---
  const outputRow = document.createElement("div");
  outputRow.className = "form-row";
  outputRow.style.marginTop = "8px";
  outputRow.innerHTML = `<div class="label">${sectionCfg.output.label}</div>`;
  const valueContainer = document.createElement("div");
  valueContainer.className = "value";
  const outputInput = document.createElement("input");
  outputInput.type = "text";
  outputInput.id = sectionCfg.output.id;
  outputInput.readOnly = true;
  outputInput.style.backgroundColor = CONFIG.rightPanel.outputFieldBackground;
  valueContainer.appendChild(outputInput);
  outputRow.appendChild(valueContainer);
  container.appendChild(outputRow);
}

/**
 * Renders the original right-side input panel.
 * @param {object} cfg The configuration object from CONFIG.rightPanel.
 */
function renderRightPanel(cfg) {
  const panel = document.getElementById("rightInputPanel");
  const tbody = panel.querySelector(".inputTable tbody");
  tbody.innerHTML = "";

  cfg.fields
    .filter((i) => !i.group)
    .forEach((field) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${field.label}</td>`;
      const tdInput = document.createElement("td");

      let el;
      if (field.type === "select") {
        el = document.createElement("select");
        field.options.forEach((opt) => {
          const o = document.createElement("option");
          o.value = opt;
          o.textContent = opt;
          if (opt === field.defaultValue) o.selected = true;
          el.appendChild(o);
        });
      } else {
        el = document.createElement("input");
        el.type = field.type;
        if (field.min !== undefined) el.min = field.min;
        if (field.max !== undefined) el.max = field.max;
        if (field.placeholder) el.placeholder = field.placeholder;
        if (field.defaultValue !== undefined) el.value = field.defaultValue;
        if (field.readOnly) {
          el.readOnly = true;
          el.style.backgroundColor = cfg.outputFieldBackground;
        }
      }
      el.id = field.id;
      tdInput.appendChild(el);
      tr.appendChild(tdInput);
      tbody.appendChild(tr);
    });

  panel.querySelectorAll(".massGroup").forEach((div) => div.remove());
  const tbl = panel.querySelector(".inputTable");
  let insertAfter = tbl;
  const groupOrder = ["TOW", "ZFW"];
  groupOrder.forEach((groupName) => {
    const groupInputs = cfg.fields.filter((field) => field.group === groupName);
    if (groupInputs.length === 0) return;

    const groupDiv = document.createElement("div");
    groupDiv.className = "massGroup";
    groupDiv.innerHTML = `<div class="groupLabel">${groupInputs[0].groupLabel}</div>`;

    groupInputs.forEach((field) => {
      const wrapper = document.createElement("div");
      wrapper.className = "massField";
      wrapper.innerHTML = `<label for="${field.id}">${field.label}:</label>`;
      const el = document.createElement("input");
      el.type = field.type;
      if (field.readOnly) {
        el.readOnly = true;
        el.style.backgroundColor = cfg.outputFieldBackground;
      }
      if (field.defaultValue) el.value = field.defaultValue;
      el.id = field.id;
      wrapper.appendChild(el);
      groupDiv.appendChild(wrapper);
    });

    const statusIndicator = document.createElement("div");
    statusIndicator.className = "mass-status-indicator";
    statusIndicator.id = `status-${groupName}`;
    groupDiv.appendChild(statusIndicator);

    insertAfter.parentNode.insertBefore(groupDiv, insertAfter.nextSibling);
    insertAfter = groupDiv;
  });
}
