/* ──────────────── scripts/chart.js ──────────────── */

/**
 * @file Manages the rendering of the main CG envelope chart, including axes, envelopes, and mass lines.
 */

/**
 * Renders the entire CG-envelope chart, including axes, grids, and all envelopes.
 * This function sets up scales, defines a clipping path, and calls sub-functions to draw each chart layer.
 * It now uses a direct formula to calculate the position of all percent MAC-related elements.
 * @param {d3.Selection} svg The D3 selection of the SVG element to draw into.
 * @param {object} cfg The chart configuration object from CONFIG.chart.
 */
function drawChart(svg, cfg) {
  // --- Derived Constants & Scales ---
  const gW = cfg.width - cfg.margins.left - cfg.margins.right;
  const gH = cfg.height - cfg.margins.top - cfg.margins.bottom;
  svg.attr("viewBox", [0, 0, cfg.width, cfg.height]);
  const g = svg.append("g").attr("transform", `translate(${cfg.margins.left},${cfg.margins.top})`);
  const xIndx = d3.scaleLinear().domain(cfg.axes.INDEX.domain).range([0, gW]);
  const y = d3.scaleLinear().domain(cfg.axes.x1000kg.domain).range([gH, 0]);

  // --- Main Rendering Layers ---
  // The order of these calls is important for the final visual stacking.
  if (cfg.envelope4) drawEnvelope(cfg.envelope4, "envelope4");
  backdrop();
  grids();
  drawBorderTicks();
  drawEnvelope(cfg.envelope, "envelope");
  if (cfg.envelope2) drawEnvelope(cfg.envelope2, "envelope2");
  if (cfg.envelope3) drawEnvelope(cfg.envelope3, "envelope3");
  axes();
  percentMacLabels();
  envelopeEdgeLabels();

  // --- Clipping Path and Group for Mass Lines ---
  // This group is created LAST to ensure mass lines are rendered on TOP of all other chart elements like the backdrop and envelopes.
  const clipMargin = cfg.clipMargin || 0;
  const clipId = "chart-area-clip";

  // Conditionally set the top boundary of the clipping rectangle based on config.
  // If clipTop is false, the y-coordinate starts from the absolute top of the SVG, effectively removing top clipping.
  const clipRectY = cfg.clipTop === false ? -cfg.margins.top : -clipMargin;
  const clipRectHeight = cfg.clipTop === false ? gH + cfg.margins.top + clipMargin : gH + 2 * clipMargin;

  g.append("defs")
    .append("clipPath")
    .attr("id", clipId)
    .append("rect")
    .attr("x", -clipMargin)
    .attr("y", clipRectY)
    .attr("width", gW + 2 * clipMargin)
    .attr("height", clipRectHeight);

  // Apply the clipping path to the dedicated mass lines group.
  g.append("g").attr("class", "mass-lines-group").attr("clip-path", `url(#${clipId})`);

  // --- Drawing Sub-functions ---

  /**
   * Calculates the INDEX value for a given %MAC and weight using a linear formula.
   * This provides the x-coordinate on the chart for a point defined by its weight and %MAC.
   * @param {number} mac The %MAC value.
   * @param {number} weight The weight in 1000 kg.
   * @param {object} axisCfg The configuration object for the %MAC axis, containing formula constants.
   * @returns {number} The calculated INDEX value.
   */
  function getIndexFromMacAndWeight(mac, weight, axisCfg) {
    // Formula: INDEX = [(%MAC - macOffset) * weight * macFactor] + indexOffset
    return (mac - axisCfg.macOffset) * weight * axisCfg.macFactor + axisCfg.indexOffset;
  }

  /**
   * Renders a single envelope polygon.
   * @param {object} envCfg The configuration for the specific envelope.
   * @param {string} className The CSS class to apply to the path.
   */
  function drawEnvelope(envCfg, className) {
    if (!envCfg || !envCfg.points) return;
    const path = d3.path();
    envCfg.points.forEach((p, i) => {
      const X = xIndx(p.indx),
        Y = y(p.kg);
      i ? path.lineTo(X, Y) : path.moveTo(X, Y);
    });
    path.closePath();
    g.append("path")
      .attr("d", path)
      .attr("class", className)
      .attr("stroke", envCfg.stroke)
      .attr("stroke-width", envCfg.strokeWidth || 1)
      .attr("stroke-dasharray", envCfg.strokeDash || "none")
      .attr("fill", "none");
  }

  /**
   * Renders a rectangular backdrop with the main envelope cut out. This creates the visual effect
   * of the area outside the operational limits being filled with a different color.
   */
  function backdrop() {
    const envPath = d3.path();
    cfg.envelope.points.forEach((p, i) => {
      const X = xIndx(p.indx),
        Y = y(p.kg);
      i ? envPath.lineTo(X, Y) : envPath.moveTo(X, Y);
    });
    envPath.closePath();

    const bg = d3.path();
    bg.rect(0, 0, gW, gH);

    g.append("path")
      .attr("d", `${bg} ${envPath}`)
      .attr("fill", cfg.bgColor || "#f0f0f0")
      .attr("fill-rule", "evenodd");
  }

  /**
   * Renders all horizontal, vertical, and slanted grid lines.
   */
  function grids() {
    const ax = cfg.axes;
    const iMin = ax.INDEX.domain[0],
      iMax = ax.INDEX.domain[1];
    const wMin = ax.x1000kg.domain[0],
      wMax = ax.x1000kg.domain[1];
    const pMacMin = ax.percentMAC.domain[0],
      pMacMax = ax.percentMAC.domain[1];

    // Weight grid (horizontal)
    g.append("g")
      .selectAll("line")
      .data(d3.range(wMin, wMax + 1, ax.x1000kg.gridStep))
      .join("line")
      .attr("x1", 0)
      .attr("x2", gW)
      .attr("y1", (d) => y(d))
      .attr("y2", (d) => y(d))
      .attr("stroke", ax.x1000kg.gridStroke)
      .attr("stroke-width", ax.x1000kg.gridStrokeWidth);
    // INDEX grid (vertical)
    g.append("g")
      .selectAll("line")
      .data(d3.range(iMin, iMax + 1, ax.INDEX.gridStep))
      .join("line")
      .attr("x1", (d) => xIndx(d))
      .attr("x2", (d) => xIndx(d))
      .attr("y1", y(wMin))
      .attr("y2", y(wMax))
      .attr("stroke", ax.INDEX.gridStroke)
      .attr("stroke-width", ax.INDEX.gridStrokeWidth);
    // %MAC grid (slanted)
    for (let v = pMacMin; v <= pMacMax; v += ax.percentMAC.gridStep) {
      // Calculate the start (top) and end (bottom) INDEX values for the slanted line using the formula
      const indexAtTop = getIndexFromMacAndWeight(v, wMax, ax.percentMAC);
      const indexAtBottom = getIndexFromMacAndWeight(v, wMin, ax.percentMAC);

      // Convert INDEX values to pixel coordinates
      const x1 = xIndx(indexAtTop); // x-coordinate at the top of the chart (y=0)
      const y1 = 0;
      const x2 = xIndx(indexAtBottom); // x-coordinate at the bottom of the chart (y=gH)
      const y2 = gH;

      g.append("path")
        .attr("d", `M ${x1} ${y1} L ${x2} ${y2}`) // Draw the line between the calculated points
        .attr("stroke", ax.percentMAC.gridStroke)
        .attr("stroke-width", ax.percentMAC.gridStrokeWidth)
        .attr("fill", "none");
    }
  }

  /**
   * Renders ticks and labels along the chart borders.
   */
  function drawBorderTicks() {
    const iMin = cfg.axes.INDEX.domain[0],
      iMax = cfg.axes.INDEX.domain[1];
    const wMin = cfg.axes.x1000kg.domain[0],
      wMax = cfg.axes.x1000kg.domain[1];
    const indexTicks = cfg.axes.INDEX.borderTicks;
    const rh = 400 / 11; // ruler height for proportion
    const majorLen = indexTicks.majorRatio * rh;
    const minorLen = indexTicks.minorRatio * rh;
    const gTop = g.append("g").attr("class", "top-border-ticks");
    const gBot = g.append("g").attr("transform", `translate(0,${gH})`);
    d3.range(iMin, iMax + 1, cfg.axes.INDEX.tickStep).forEach((v) => {
      const xPos = xIndx(v);
      const isMajor = v % 5 === 0;
      gTop
        .append("line")
        .attr("x1", xPos)
        .attr("x2", xPos)
        .attr("y1", 0)
        .attr("y2", -(isMajor ? majorLen : minorLen))
        .attr("stroke", cfg.axes.INDEX.stroke)
        .attr("stroke-width", isMajor ? indexTicks.majorWidth : indexTicks.minorWidth);
      gBot
        .append("line")
        .attr("x1", xPos)
        .attr("x2", xPos)
        .attr("y1", 0)
        .attr("y2", isMajor ? majorLen : minorLen)
        .attr("stroke", cfg.axes.INDEX.stroke)
        .attr("stroke-width", isMajor ? indexTicks.majorWidth : indexTicks.minorWidth);
      if (v % cfg.axes.INDEX.labelEvery === 0) {
        g.append("text")
          .attr("x", xIndx(v))
          .attr("y", gH + 5 + cfg.axes.INDEX.titleFontSize)
          .attr("text-anchor", "middle")
          .attr("dominant-baseline", "hanging")
          .attr("font-size", cfg.axes.INDEX.titleFontSize)
          .text(v);
      }
    });

    const sideCfg = cfg.axes.x1000kg.borderTicks;
    d3.range(wMin, wMax + 1, cfg.axes.x1000kg.tickStep).forEach((v) => {
      const yPos = y(v);
      g.append("line")
        .attr("x1", 0)
        .attr("x2", -sideCfg.length)
        .attr("y1", yPos)
        .attr("y2", yPos)
        .attr("stroke", cfg.axes.x1000kg.stroke)
        .attr("stroke-width", cfg.axes.x1000kg.strokeWidth);
      if (v % cfg.axes.x1000kg.labelEvery === 0) {
        g.append("text")
          .attr("x", -cfg.axes.x1000kg.borderTicks.length - 4)
          .attr("y", y(v))
          .attr("text-anchor", "end")
          .attr("dominant-baseline", "middle")
          .attr("font-size", cfg.axes.x1000kg.titleFontSize)
          .text(v);
      }
      g.append("line")
        .attr("x1", gW)
        .attr("x2", gW + sideCfg.length)
        .attr("y1", yPos)
        .attr("y2", yPos)
        .attr("stroke", cfg.axes.x1000kg.stroke)
        .attr("stroke-width", cfg.axes.x1000kg.strokeWidth);
    });
    g.append("text")
      .attr("x", -cfg.axes.x1000kg.borderTicks.length - 4)
      .attr("y", y(wMax))
      .attr("text-anchor", "end")
      .attr("dominant-baseline", "middle")
      .attr("font-size", cfg.axes.x1000kg.titleFontSize)
      .text(wMax);
  }

  /**
   * Renders labels on the edges of the envelopes.
   */
  function envelopeEdgeLabels() {
    const place = (pts, edgeIndex, text, offsetPx, flip = false) => {
      const n = pts.length;
      if (n === 0) return;
      const ei = edgeIndex < 0 ? n + edgeIndex : edgeIndex;
      const a = pts[ei],
        b = pts[(ei + 1) % n];
      const A = [xIndx(a.indx), y(a.kg)];
      const B = [xIndx(b.indx), y(b.kg)];
      const mx = (A[0] + B[0]) / 2,
        my = (A[1] + B[1]) / 2;
      const dx = B[0] - A[0],
        dy = B[1] - A[1];
      const len = Math.hypot(dx, dy) || 1;
      let nx = -dy / len,
        ny = dx / len;
      const polyPix = pts.map((p) => [xIndx(p.indx), y(p.kg)]);
      if (d3.polygonContains(polyPix, [mx + nx * 6, my + ny * 6])) {
        nx = -nx;
        ny = -ny;
      }
      const px = mx + nx * (offsetPx || 10);
      const py = my + ny * (offsetPx || 10);
      let angle = (Math.atan2(dy, dx) * 180) / Math.PI;
      if (flip) angle += 180;
      const grp = g.append("g").attr("transform", `translate(${px},${py}) rotate(${angle})`);
      grp
        .append("text")
        .attr("text-anchor", "middle")
        .attr("dominant-baseline", "central")
        .attr("font-size", 11)
        .text(text);
    };
    if (cfg.envelopeLabels?.envelope1) {
      cfg.envelopeLabels.envelope1.forEach((l) =>
        place(cfg.envelope.points, l.edgeIndex, l.text, l.offset, l.edgeIndex !== 1)
      );
    }
    if (cfg.envelope2 && cfg.envelopeLabels?.envelope2) {
      cfg.envelopeLabels.envelope2.forEach((l) => place(cfg.envelope2.points, l.edgeIndex, l.text, l.offset));
    }
    if (cfg.envelope3 && cfg.envelopeLabels?.envelope3) {
      cfg.envelopeLabels.envelope3.forEach((l) => place(cfg.envelope3.points, l.edgeIndex, l.text, l.offset));
    }
    if (cfg.envelope4 && cfg.envelopeLabels?.envelope4) {
      cfg.envelopeLabels.envelope4.forEach((l) => place(cfg.envelope4.points, l.edgeIndex, l.text, l.offset));
    }
  }

  /**
   * Renders the main X (INDEX) and Y (Weight) axes with titles.
   */
  function axes() {
    const ax = cfg.axes;
    g.append("g").call((sel) => {
      sel
        .selectAll(".domain,.tick line")
        .attr("stroke", ax.x1000kg.stroke)
        .attr("stroke-width", ax.x1000kg.strokeWidth);
      sel
        .append("text")
        .attr("transform", `translate(${-30},${gH / 2}) rotate(-90)`)
        .attr("text-anchor", "middle")
        .attr("fill", ax.x1000kg.stroke)
        .attr("font-size", 10)
        .text(ax.x1000kg.title);
    });
    g.append("g")
      .attr("transform", `translate(0,${gH})`)
      .call((sel) => {
        sel.selectAll(".domain,.tick line").attr("stroke", ax.INDEX.stroke).attr("stroke-width", ax.INDEX.strokeWidth);
        sel
          .append("text")
          .attr("x", gW / 2)
          .attr("y", 35)
          .attr("text-anchor", "middle")
          .attr("fill", ax.INDEX.stroke)
          .attr("font-size", 10)
          .text(ax.INDEX.title);
      });
  }

  /**
   * Renders the custom-placed %MAC labels and title near the top of the chart.
   */
  function percentMacLabels() {
    const axCfg = cfg.axes.percentMAC;
    const pMacMin = axCfg.domain[0],
      pMacMax = axCfg.domain[1];
    const yPix = axCfg.labelsOffset * gH;
    const group = g.append("g");
    d3.range(pMacMin, pMacMax + 1e-9, cfg.axes.percentMAC.labelEvery).forEach((pMacVal) => {
      // To position the label, we first find the weight (in 1000kg) at the label's y-pixel coordinate.
      const weightAtLabelY = y.invert(yPix);
      // Then, calculate the INDEX value for the current %MAC at that specific weight.
      const indexAtLabel = getIndexFromMacAndWeight(pMacVal, weightAtLabelY, axCfg);
      // Finally, convert the calculated INDEX into an x-pixel coordinate for positioning.
      const xPix = xIndx(indexAtLabel);

      const lblGrp = group.append("g");
      const txt = lblGrp
        .append("text")
        .attr("x", xPix)
        .attr("y", yPix)
        .attr("text-anchor", "middle")
        .attr("dominant-baseline", "middle")
        .attr("fill", axCfg.labelsStroke)
        .attr("font-size", 10)
        .text(d3.format(".0f")(pMacVal));
      const bb = txt.node().getBBox();
      lblGrp
        .insert("rect", "text")
        .attr("x", bb.x - 2)
        .attr("y", bb.y)
        .attr("width", bb.width + 4)
        .attr("height", bb.height)
        .attr("fill", cfg.bgColor || "#fff");
    });
    const weightAtLabelY = y.invert(yPix);
    const indexAtLabel = getIndexFromMacAndWeight(pMacMin, weightAtLabelY, axCfg);
    const xFirst = xIndx(indexAtLabel);
    const titleGroup = group.append("g");
    const titleText = titleGroup
      .append("text")
      .attr("x", xFirst - 8)
      .attr("y", yPix)
      .attr("text-anchor", "end")
      .attr("dominant-baseline", "middle")
      .attr("fill", axCfg.labelsStroke)
      .attr("font-size", 11)
      .text(axCfg.title);
    const titleBB = titleText.node().getBBox();
    titleGroup
      .insert("rect", "text")
      .attr("x", titleBB.x - 2)
      .attr("y", titleBB.y)
      .attr("width", titleBB.width + 4)
      .attr("height", titleBB.height)
      .attr("fill", cfg.bgColor || "#fff");
  }
}

/**
 * Draws the vertical ZFW and TOW lines, updates their CG %MAC values, and sets status indicators.
 * This function determines the final X-coordinate from the rulers, draws the vertical line to the
 * appropriate weight on the chart, and then calculates the corresponding %MAC value using an inverse formula.
 * @param {d3.Selection} svg The D3 selection of the chart's SVG element.
 * @param {object} rulersCfg The configuration from CONFIG.rulers.
 * @param {object} chartCfg The configuration from CONFIG.chart.
 */
function drawMassLines(svg, rulersCfg, chartCfg) {
  // Select the dedicated, pre-clipped group for drawing mass lines.
  const massLinesGroup = svg.select(".mass-lines-group");
  massLinesGroup.selectAll("*").remove(); // Clear previous lines and markers

  const gW = chartCfg.width - chartCfg.margins.left - chartCfg.margins.right;
  const gH = chartCfg.height - chartCfg.margins.top - chartCfg.margins.bottom;
  const xScale = d3.scaleLinear().domain(chartCfg.axes.INDEX.domain).range([0, gW]);
  const yScale = d3.scaleLinear().domain(chartCfg.axes.x1000kg.domain).range([gH, 0]);

  /**
   * Calculates the final X-coordinate for a mass line based on all ruler inputs.
   * @param {string} type The mass type ('ZFW' or 'TOW').
   * @returns {number} The final X pixel coordinate.
   */
  const calculateX = (type) => {
    const baseUnit = rulersCfg.width / rulersCfg.ruler1Range;
    const mapping = type === "ZFW" ? rulersCfg.lineMapping.filter((m) => m.id !== "fuelIndex") : rulersCfg.lineMapping;
    let x = baseUnit * Number(document.getElementById("dryOpIndex").value);
    mapping.slice(1).forEach(({ id, ruler, direction, unitPerValue }) => {
      if (direction === "left" || direction === "right") {
        const ratio = rulersCfg.ratios[ruler - 1] || 1;
        const pxPerVal = (baseUnit * ratio) / unitPerValue;
        const v = Number(document.getElementById(id).value);
        x += (direction === "right" ? 1 : -1) * v * pxPerVal;
      }
    });
    return x;
  };

  /**
   * Calculates the CG %MAC value based on a line's final pixel coordinates.
   * It uses the inverse of the standard formula to solve for %MAC from INDEX and weight.
   * @param {number} x_px The final X pixel coordinate.
   * @param {number} y_px The final Y pixel coordinate.
   * @returns {number} The calculated CG %MAC value.
   */
  const calculateMac = (x_px, y_px) => {
    // Convert pixel coordinates back to chart data values (INDEX and weight)
    const finalIndex = xScale.invert(x_px);
    const massThousand = yScale.invert(y_px);

    // Retrieve formula constants from the configuration
    const { macOffset, macFactor, indexOffset } = chartCfg.axes.percentMAC;

    // Inverse Formula: %MAC = [(INDEX - indexOffset) / (weight * macFactor)] + macOffset
    // This is derived from the primary formula: INDEX = [(%MAC - macOffset) * weight * macFactor] + indexOffset
    if (massThousand <= 0 || macFactor === 0) {
      // Avoid division by zero, though unlikely with typical chart domains.
      return NaN;
    }
    const mac = (finalIndex - indexOffset) / (massThousand * macFactor) + macOffset;

    return mac;
  };

  const markerRadius = chartCfg.circleRadius || 5;
  // Iterate based on the configured drawing order to ensure ZFW is drawn on top of TOW.
  chartCfg.lineOrder.forEach((type) => {
    const weightId = type === "ZFW" ? "zeroFuelWeight" : "takeoffWeight";
    const macId = type === "ZFW" ? "zeroFuelMac" : "takeoffMac";
    const massThousand = Number(document.getElementById(weightId).value);

    if (!massThousand) return;

    const x = calculateX(type);
    const y_px = yScale(massThousand);
    const lineColor = chartCfg.massLineColors[type] || "black";
    const envelope = type === "ZFW" ? chartCfg.envelope2 : chartCfg.envelope;

    // The line starts from the top margin of the SVG, ensuring it's fully visible when top clipping is off.
    massLinesGroup
      .append("line")
      .attr("x1", x)
      .attr("x2", x)
      .attr("y1", -chartCfg.margins.top)
      .attr("y2", y_px)
      .attr("stroke", lineColor)
      .attr("stroke-width", 2);

    massLinesGroup.append("circle").attr("cx", x).attr("cy", y_px).attr("r", markerRadius).attr("fill", lineColor);

    const finalMac = calculateMac(x, y_px);
    const macInput = document.getElementById(macId);
    if (macInput) macInput.value = finalMac.toFixed(1);

    const envPoly = envelope.points.map((p) => [xScale(p.indx), yScale(p.kg)]);
    const isInside = d3.polygonContains(envPoly, [x, y_px]);
    const statusIndicator = document.getElementById(`status-${type}`);
    if (statusIndicator) {
      const statusConfig = isInside ? CONFIG.rightPanel.status.within : CONFIG.rightPanel.status.outside;
      statusIndicator.textContent = statusConfig.text;
      statusIndicator.style.color = statusConfig.color;
    }
  });
}
