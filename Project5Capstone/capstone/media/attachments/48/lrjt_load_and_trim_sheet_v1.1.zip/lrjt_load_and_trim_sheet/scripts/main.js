// v1.1

/**
 * @file Main configuration and entry point for the application.
 */

/**
 * @constant {object} CONFIG
 * @description Global configuration object for the entire application.
 * Contains settings for inputs, rulers, the main chart, and status indicators.
 */
const CONFIG = {
  // ---------- left inputs panel configuration ----------
  leftPanel: {
    sections: [
      {
        type: "weightCalculations",
        title: "WEIGHT CALCULATIONS",
        fields: [
          { id: "dryOpWeight", label: "DRY OPERATING WEIGHT", type: "input", defaultValue: "110000" },
          { id: "pantryDeviation", label: "WEIGHT DEVIATION (PANTRY)", type: "input", defaultValue: "100" },
          { id: "correctedDryOpWeight", label: "CORRECTED DRY OPER WEIGHT", type: "output" },
          { id: "cargo", label: "CARGO", type: "input", defaultValue: "11500" },
          { id: "passengers", label: "PASSENGERS", type: "passengers", default1: "240", default2: "75" },
          { id: "zeroFuelWeightCalc", label: "ZERO FUEL WEIGHT", type: "output" },
          { id: "totalFuel", label: "TOTAL FUEL", type: "input", defaultValue: "72000" },
          { id: "totalWeight", label: "TOTAL WEIGHT", type: "output" },
        ],
      },
      {
        type: "dowConditions",
        title: "DRY OPERATING WEIGHT CONDITIONS",
        fields: [
          { id: "dowWeight", label: "WEIGHT (1000 kg)", type: "input", defaultValue: "110" },
          { id: "dowCg", label: "CG (% MAC)", type: "input", defaultValue: "31.0" },
        ],
        formula: "I=[(CG-25) x W x 0.029] + 100",
        output: { id: "dowIndex", label: "DRY OPER WEIGHT INDEX" },
      },
      {
        type: "zones",
        title: "ZONES",
        headers: ["ZONES", "E", "F", "G"],
        rows: [
          {
            label: "WEIGHT(kg) DEVIATION",
            fields: [
              { id: "zoneDevE", type: "input", defaultValue: "0" },
              { id: "zoneDevF", type: "input", defaultValue: "100" },
              { id: "zoneDevG", type: "input", defaultValue: "0" },
            ],
          },
        ],
      },
      {
        type: "indexCorrection",
        title: "BASIC INDEX CORRECTION",
        col1Title: "DRY OPER. WEIGHT DEVIATION",
        col2Title: "ZONES",
        subHeaders: ["E", "F", "G"],
        refValues: [
          { label: "+100kg", e: -0.99, f: -0.51, g: 0.92 },
          { label: "-100kg", e: 0.99, f: 0.51, g: -0.92 },
        ],
        output: { id: "indexCorrection", label: "INDEX CORRECTION" },
      },
    ],
  },
  // ---------- right inputs panel configuration ----------
  rightPanel: {
    /** @property {object[]} fields - Defines the input fields in the panel. */
    fields: [
      { id: "cargo1", label: "CARGO 1", type: "number", min: 0, defaultValue: "2500" },
      { id: "cargo2", label: "CARGO 2", type: "number", min: 0, defaultValue: "3000" },
      { id: "cargo3", label: "CARGO 3", type: "number", min: 0, defaultValue: "3000" },
      { id: "cargo4", label: "CARGO 4", type: "number", min: 0, defaultValue: "2000" },
      { id: "cargo5", label: "CARGO 5", type: "number", min: 0, defaultValue: "1000" },
      { id: "cargo0a", label: "CABIN 0A", type: "number", min: 0, defaultValue: "20" },
      { id: "cargo0b", label: "CABIN 0B", type: "number", min: 0, defaultValue: "120" },
      { id: "cargo0c", label: "CABIN 0C", type: "number", min: 0, defaultValue: "100" },
      {
        id: "fuelIndex",
        label: "FUEL INDEX (±)",
        type: "select",
        options: [
          "-2",
          "-4",
          "-6",
          "-3",
          "-1",
          "+2",
          "+4",
          "+6",
          "+4",
          "+2",
          "0",
          "-2",
          "-4",
          "-6",
          "-8",
          "-9",
          "-11",
          "-13",
          "-14",
          "-16",
          "-18",
          "-19",
          "-23",
          "-25",
          "-26",
          "-26",
          "-24",
          "-21",
          "-19",
          "-16",
          "-13",
          "-10",
          "-7",
          "-5",
          "-2",
          "+1",
          "+3",
          "+3",
          "+4",
          "+4",
          "+8",
        ],
        defaultValue: "+8",
      },
      {
        id: "takeoffWeight",
        group: "TOW",
        groupLabel: "TAKE OFF",
        label: "WEIGHT (1000 kg)",
        type: "number",
        min: 0,
        max: 212,
        placeholder: "max 212",
        defaultValue: "211.6",
      },
      {
        id: "takeoffMac",
        group: "TOW",
        groupLabel: "TAKE OFF",
        label: "CG% MAC",
        type: "text",
        readOnly: true,
      },
      {
        id: "zeroFuelWeight",
        group: "ZFW",
        groupLabel: "ZFW CDU INPUT",
        label: "WEIGHT (1000 kg)",
        type: "number",
        min: 0,
        max: 164,
        defaultValue: "139.6",
        placeholder: "max 164",
      },
      {
        id: "zeroFuelMac",
        group: "ZFW",
        groupLabel: "ZFW CDU INPUT",
        label: "CG% MAC",
        type: "text",
        readOnly: true,
      },
    ],
    /** @property {object} status - Configuration for mass status indicators. */
    status: {
      within: { text: "Within Limits", color: "green" },
      outside: { text: "Outside Limits", color: "red" },
    },
    /** @property {string} outputFieldBackground - Background color for read-only output fields. */
    outputFieldBackground: "#e6f7ff",
  },

  /* ---------- rulers configuration ---------- */
  rulers: {
    width: 880,
    height: 300,
    rulerCount: 10,
    ruler1Range: 210,
    refTick: 21.5,
    majorRatio: 0.3,
    minorRatio: 0.15,
    majorWidth: 0.9,
    minorWidth: 0.9,
    rectHRatio: 0.8,
    rightRectWidth: 50,
    ratios: [1, 92.5 / 135, 96.5 / 220, 90 / 315, 91 / 205, 95 / 265, 96 / 170, 98 / 190, 86.5 / 120, 0.98],
    noMinor: new Set([...Array(10).keys()]),
    rectWidthInCells: { 2: 8, 3: 8, 4: 12, 5: 8, 6: 8, 7: 8, 8: 8, 9: 8, 10: 8 },
    rectSide: {
      2: "right",
      3: "right",
      4: "right",
      5: "right",
      6: "right",
      7: "right",
      8: "right",
      9: "right",
      10: "right",
    },
    triSide: { 2: "left", 3: "left", 4: "right", 5: "right", 6: "right", 7: "left", 8: "left", 9: "right", 10: "both" },
    anchor: (i) => (i === 10 ? "left" : "ref"),
    identifierLabels: {
      1: "INDEX",
      2: "CARGO 1",
      3: "CARGO 2",
      4: "CARGO 3",
      5: "CARGO 4",
      6: "CARGO 5",
      7: "CABIN 0A",
      8: "CABIN 0B",
      9: "CABIN 0C",
      10: "FUEL INDEX",
    },
    dataLabels: {
      2: "500 kg",
      3: "500 kg",
      4: "500 kg",
      5: "500 kg",
      6: "250 kg",
      7: "5 PAX",
      8: "20 PAX",
      9: "10 PAX",
      10: "INDEX",
    },
    labelPos: {
      2: "center",
      3: "center",
      4: "center",
      5: "center",
      6: "center",
      7: "center",
      8: "center",
      9: "center",
      10: "center",
    },
    labelFont: {
      1: { size: 11, bold: false },
      2: { size: 11 },
      3: { size: 11 },
      4: { size: 11 },
      5: { size: 11 },
      6: { size: 11 },
      7: { size: 12 },
      8: { size: 11 },
      9: { size: 11 },
      10: { size: 11 },
    },
    triW: 5,
    lineMapping: [
      { id: "dryOpIndex", ruler: 1, direction: "vertical", unitPerValue: 1 },
      { id: "cargo1", ruler: 2, direction: "left", unitPerValue: 100 },
      { id: "cargo2", ruler: 3, direction: "left", unitPerValue: 100 },
      { id: "cargo3", ruler: 4, direction: "right", unitPerValue: 100 },
      { id: "cargo4", ruler: 5, direction: "right", unitPerValue: 100 },
      { id: "cargo5", ruler: 6, direction: "right", unitPerValue: 50 },
      { id: "cargo0a", ruler: 7, direction: "left", unitPerValue: 1 },
      { id: "cargo0b", ruler: 8, direction: "left", unitPerValue: 4 },
      { id: "cargo0c", ruler: 9, direction: "right", unitPerValue: 2 },
      { id: "fuelIndex", ruler: 10, direction: "right", unitPerValue: 1 },
    ],
  },

  /* ---------- chart configuration ---------- */
  chart: {
    width: 1000,
    height: 474,
    margins: { top: 12, right: 60, bottom: 50, left: 60 },
    bgColor: "#fff",
    massLineColors: { ZFW: "red", TOW: "limegreen" },
    lineOrder: ["TOW", "ZFW"],
    circleRadius: 5,
    clipTop: false,
    clipMargin: 0,
    axes: {
      INDEX: {
        domain: [0, 210],
        tickStep: 1,
        gridStep: 210,
        labelEvery: 10,
        title: "INDEX",
        titleFontSize: 10,
        stroke: "#000",
        strokeWidth: 1,
        gridStroke: "#808080ff",
        gridStrokeWidth: 0.6,
        borderTicks: { majorRatio: 0.25, minorRatio: 0.15, majorWidth: 0.8, minorWidth: 0.6 },
      },
      x1000kg: {
        domain: [100, 240],
        tickStep: 2,
        gridStep: 10,
        labelEvery: 10,
        title: "AIRCRAFTFTWEIGHT(1000 kg)",
        titleFontSize: 10,
        stroke: "#000",
        strokeWidth: 0.8,
        gridStroke: "#808080ff",
        gridStrokeWidth: 0.6,
        borderTicks: { step: 1, length: 6 },
      },
      percentMAC: {
        domain: [17, 40],
        gridStep: 1,
        labelEvery: 1,
        title: "AIRCRAFTCG % MAC →",
        labelsStroke: "#000000ff",
        labelsOffset: 0.11,
        macOffset: 25,
        macFactor: 0.029,
        indexOffset: 100,
        gridStroke: "#808080ff",
        gridStrokeWidth: 0.6,
      },
    },
    envelope: {
      stroke: "#000000ff",
      strokeWidth: 1.5,
      points: [
        { indx: 86.8, kg: 100 },
        { indx: 53.5, kg: 212 },
        { indx: 157, kg: 212 },
        { indx: 173.5, kg: 208 },
        { indx: 169, kg: 187 },
        { indx: 112.5, kg: 120 },
        { indx: 107.5, kg: 100 },
      ],
    },
    envelope2: {
      stroke: "#000000ff",
      strokeWidth: 1.5,
      points: [
        { indx: 91.5, kg: 100 },
        { indx: 74, kg: 164 },
        { indx: 157, kg: 164 },
        { indx: 130, kg: 100 },
      ],
    },
    envelope3: {
      stroke: "#000000ff",
      strokeWidth: 1.5,
      points: [
        { indx: 97, kg: 100 },
        { indx: 79.5, kg: 164 },
        { indx: 157, kg: 164 },
        { indx: 130, kg: 100 },
      ],
    },
    envelope4: {
      stroke: "grey",
      strokeWidth: 1.5,
      strokeDash: "5, 5",
      points: [
        { indx: 86.8, kg: 100 },
        { indx: 64.8, kg: 174 },
        { indx: 161.9, kg: 174 },
        { indx: 112.5, kg: 120 },
        { indx: 107.5, kg: 100 },
      ],
    },
    envelopeLabels: {
      envelope1: [
        { edgeIndex: 0, text: "TAKEOFF OPERATIONAL LIMIT", offset: 10 },
        { edgeIndex: 1, text: "MTOW = 212 000 kg", offset: 10 },
        { edgeIndex: -3, text: "TAKEOFF OPERATIONAL LIMIT", offset: 10 },
      ],
      envelope2: [{ edgeIndex: 0, text: "FUEL <35 000 kg", offset: 10 }],
      envelope3: [
        { edgeIndex: 0, text: "FUEL >35 000 kg", offset: 10 },
        { edgeIndex: 1, text: "MZFW = 164 000 kg", offset: 10 },
      ],
      envelope4: [{ edgeIndex: 1, text: "MLW = 174 000 kg", offset: 10 }],
    },
  },
};

/**
 * @function
 * @name DOMContentLoaded
 * @description Entry point for the script, runs after the DOM is fully loaded.
 */
document.addEventListener("DOMContentLoaded", () => {
  const rulersSvg = d3.select("#rulers").attr("width", CONFIG.chart.width).attr("height", CONFIG.rulers.height);
  const chartSvg = d3.select("#chart").attr("width", CONFIG.chart.width).attr("height", CONFIG.chart.height);

  rulersSvg
    .append("defs")
    .append("clipPath")
    .attr("id", "rulers-clip")
    .append("rect")
    .attr("width", CONFIG.rulers.width)
    .attr("height", CONFIG.rulers.height);

  renderLeftPanel(CONFIG.leftPanel);
  renderRightPanel(CONFIG.rightPanel);

  const gRulers = rulersSvg
    .append("g")
    .attr("clip-path", "url(#rulers-clip)")
    .attr("transform", `translate(${CONFIG.chart.margins.left},0)`);

  let manualIndexOverride = false;
  let isSyncing = false; // Flag to prevent infinite loops in field synchronization.

  /**
   * Safely parses a number from an input field, returning 0 if it's not a valid number.
   * @param {string} id - The ID of the input element.
   * @returns {number} The parsed number.
   */
  const getNumber = (id) => parseFloat(document.getElementById(id)?.value) || 0;

  /**
   * Central function to perform all calculations and update the DOM with the results.
   * This is a dependency for the main `updateAllVisuals` function.
   */
  function calculateAndDisplayOutputs() {
    // Section 1: Weight Calculations
    const dryOpWeight = getNumber("dryOpWeight");
    const pantryDev = getNumber("pantryDeviation");
    const correctedDryOpWeight = dryOpWeight + pantryDev;
    document.getElementById("correctedDryOpWeight").value = correctedDryOpWeight.toFixed(0);

    const cargo = getNumber("cargo");
    const pass1 = getNumber("passengers1");
    const pass2 = getNumber("passengers2");
    const totalPassengers = pass1 + pass2;
    const zeroFuelWeight = correctedDryOpWeight + cargo + totalPassengers;
    document.getElementById("zeroFuelWeightCalc").value = zeroFuelWeight.toFixed(0);

    const totalFuel = getNumber("totalFuel");
    const totalWeight = zeroFuelWeight + totalFuel;
    document.getElementById("totalWeight").value = totalWeight.toFixed(0);

    // Section 2: DOW Conditions
    const dowWeight = getNumber("dowWeight");
    const dowCg = getNumber("dowCg");
    const dowIndex = (dowCg - 25) * dowWeight * 0.029 + 100;
    document.getElementById("dowIndex").value = dowIndex.toFixed(2);

    // Section 4: Index Correction
    const devE = getNumber("zoneDevE");
    const devF = getNumber("zoneDevF");
    const devG = getNumber("zoneDevG");
    const ref = CONFIG.leftPanel.sections.find((s) => s.type === "indexCorrection").refValues;
    const indexCorrection =
      (devE / 100) * (devE > 0 ? ref[0].e : ref[1].e) +
      (devF / 100) * (devF > 0 ? ref[0].f : ref[1].f) +
      (devG / 100) * (devG > 0 ? ref[0].g : ref[1].g);
    document.getElementById("indexCorrection").value = indexCorrection.toFixed(2);

    // Final Corrected Index calculation, respecting manual override
    if (!manualIndexOverride) {
      const finalCorrectedIndex = dowIndex + indexCorrection;
      document.getElementById("dryOpIndex").value = finalCorrectedIndex.toFixed(2);
    }
  }

  drawRulers(gRulers, CONFIG.rulers);
  drawChart(chartSvg, CONFIG.chart);

  /**
   * @function updateAllVisuals
   * @description Centralized update function that serves as the primary response to any input change.
   * It orchestrates the recalculation of all derived values and the redrawing of all dynamic SVG elements.
   * This function ensures that any single input change is reflected across the entire application state.
   */
  function updateAllVisuals() {
    calculateAndDisplayOutputs();
    gRulers.selectAll(".input-line, .input-line-marker").remove();
    CONFIG.chart.lineOrder.forEach((type) => {
      drawInputLines(gRulers, CONFIG.rulers, type);
    });
    drawMassLines(chartSvg, CONFIG.rulers, CONFIG.chart);
  }

  /**
   * @function syncDowFields
   * @description Handles bidirectional synchronization between the "DRY OPERATING WEIGHT" (kg) and "WEIGHT (1000 kg)" fields.
   * It converts the value from the source field and updates the target field, then triggers a full application update.
   * A flag `isSyncing` is used to prevent an infinite recursive loop between the two input event listeners.
   * @param {HTMLInputElement} sourceElement - The input element that triggered the change event.
   */
  function syncDowFields(sourceElement) {
    if (isSyncing) return; // Prevent recursive calls.
    isSyncing = true;

    const sourceId = sourceElement.id;
    const sourceValue = parseFloat(sourceElement.value) || 0;
    const dryOpWeightInput = document.getElementById("dryOpWeight");
    const dowWeightInput = document.getElementById("dowWeight");

    // Perform the unit conversion based on which field was changed.
    if (sourceId === "dryOpWeight") {
      dowWeightInput.value = (sourceValue / 1000).toFixed(1);
    } else if (sourceId === "dowWeight") {
      dryOpWeightInput.value = (sourceValue * 1000).toFixed(0);
    }

    manualIndexOverride = false; // A change here implies calculations should be automatic.
    updateAllVisuals(); // Trigger a full recalculation and redraw.

    isSyncing = false; // Reset the flag after the update is complete.
  }

  // Initial calculation and drawing on page load
  updateAllVisuals();

  // --- Event Listeners ---

  const leftPanelSections = CONFIG.leftPanel.sections;
  const rightPanelFields = CONFIG.rightPanel.fields;

  // Gather all IDs from inputs that are not read-only outputs.
  const allInputIds = [
    ...leftPanelSections.flatMap((s) => s.fields?.filter((f) => f.type !== "output").map((f) => f.id) || []),
    ...leftPanelSections.flatMap((s) => s.rows?.flatMap((r) => r.fields.map((f) => f.id)) || []),
    ...rightPanelFields.filter((f) => !f.readOnly).map((f) => f.id),
  ].filter(Boolean);

  const passengerField = leftPanelSections.flatMap((s) => s.fields || []).find((f) => f.type === "passengers");
  if (passengerField) {
    allInputIds.push(passengerField.id + "1", passengerField.id + "2");
  }

  // Define fields that have special synchronization logic and should not use the generic listener.
  const fieldsWithSpecialHandlers = new Set(["dryOpIndex", "dryOpWeight", "dowWeight"]);

  // Attach a generic event listener to all standard input fields.
  allInputIds
    .filter((id) => !fieldsWithSpecialHandlers.has(id))
    .forEach((id) => {
      const element = document.getElementById(id);
      if (element) {
        element.addEventListener("input", () => {
          manualIndexOverride = false;
          updateAllVisuals();
        });
      }
    });

  // Attach special listener for the 'dryOpIndex' field to handle manual overrides.
  document.getElementById("dryOpIndex").addEventListener("input", () => {
    manualIndexOverride = true;
    // Only update visuals, as a manual index change does not require recalculating other outputs.
    gRulers.selectAll(".input-line, .input-line-marker").remove();
    CONFIG.chart.lineOrder.forEach((type) => drawInputLines(gRulers, CONFIG.rulers, type));
    drawMassLines(chartSvg, CONFIG.rulers, CONFIG.chart);
  });

  // Attach listeners for the synchronized weight fields.
  document.getElementById("dryOpWeight").addEventListener("input", (e) => syncDowFields(e.target));
  document.getElementById("dowWeight").addEventListener("input", (e) => syncDowFields(e.target));
});
